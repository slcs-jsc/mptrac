#ifdef GPU
#include <cuda.h>
#endif

#include <thrust/device_ptr.h>
#include <thrust/sort.h>

extern "C" void thrustSortWrapper(
	double *__restrict__ c,
	int n, 
	int *__restrict__ index)
{
#ifdef GPU
	thrust::device_ptr<double> c_ptr = thrust::device_pointer_cast(c);
	thrust::device_ptr<int> i_ptr = thrust::device_pointer_cast(index);
	thrust::sort_by_key(c_ptr, c_ptr + n, i_ptr);
#else
thrust::sort_by_key(c, c + n, index);
#endif
}

