#include "thrustsort.h"

#include <stdio.h>

int main(void) {
  double key[] = {4.0, 1.0, 3.0, 2.0};
  int index[] = {0, 1, 2, 3};

  thrustSortWrapper(key, 4, index);
  if (key[0] != 1.0 || key[1] != 2.0 || key[2] != 3.0 || key[3] != 4.0 ||
      index[0] != 1 || index[1] != 3 || index[2] != 2 || index[3] != 0) {
    fputs("CPU Thrust sort check failed\n", stderr);
    return 1;
  }

  puts("CPU Thrust sort check passed");
  return 0;
}
