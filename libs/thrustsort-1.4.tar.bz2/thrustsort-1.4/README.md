# MPTRAC Thrust sort wrapper 1.4

This source-only archive replaces the precompiled x86-64 libraries in version
1.3. It exposes `thrustSortWrapper` to MPTRAC's C code. NVIDIA Thrust itself
is not bundled; provide compatible Thrust headers separately when selecting
this optional wrapper.

- `make cpu` builds the OpenMP/Thrust CPU library for the current host.
- `make check-cpu` runs a small C caller test of sorting and index order.
- `make gpu` builds the CUDA/Thrust GPU library for the current host. Set
  `NVCCFLAGS` as needed for the target GPU architecture.
- `THRUST_INCLUDE_DIR` may point to a nonstandard CUDA/Thrust include directory.
  Otherwise the build checks `CUDA_HOME` or `CUDA_PATH` for CUDA 13's
  `include/cccl` layout, then uses their `include` directory or the
  compiler's default include paths.

Neither target runs a GPU program or submits a job. The GPU library needs a
separate MPTRAC link and runtime check on the intended system.
