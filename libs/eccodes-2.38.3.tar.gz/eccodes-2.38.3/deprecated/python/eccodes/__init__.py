from __future__ import absolute_import
import sys

from .eccodes import *
from .eccodes import __version__

