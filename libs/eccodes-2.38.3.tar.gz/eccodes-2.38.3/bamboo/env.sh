#!/bin/bash

# export ctest_parallel="no"
make_parallel="yes"
