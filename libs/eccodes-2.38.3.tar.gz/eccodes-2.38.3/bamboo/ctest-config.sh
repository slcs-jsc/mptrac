#!/bin/bash

ctest_parallel="yes"
