#!/bin/sh
set -e

./get
./set
./iterator
./keys_iterator
./precision


