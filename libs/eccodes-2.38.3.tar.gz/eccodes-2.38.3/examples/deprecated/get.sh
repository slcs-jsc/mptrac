#!/bin/sh

. ./include.sh

${examples_dir}/get > /dev/null


