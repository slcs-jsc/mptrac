#!/bin/sh

. ./include.sh

${examples_dir}/precision > /dev/null


