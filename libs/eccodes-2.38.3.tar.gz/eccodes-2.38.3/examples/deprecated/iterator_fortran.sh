#!/bin/sh

. ./include.sh

${examples_dir}/iterator_fortran > /dev/null


